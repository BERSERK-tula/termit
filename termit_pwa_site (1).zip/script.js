
let cartCount = 0;
let cartSum = 0;
const price = 7000;

function updateCart() {
    document.getElementById('cart-indicator').innerText = `В корзине: ${cartCount} • ${cartSum} ₽`;
    document.getElementById('cart-details').innerText = `Вы добавили ${cartCount} товаров на сумму ${cartSum} ₽`;
}

function addToCart() {
    cartCount++;
    cartSum += price;
    updateCart();
}

function removeFromCart() {
    if (cartCount > 0) {
        cartCount--;
        cartSum -= price;
    }
    updateCart();
}

function toggleCart() {
    const popup = document.getElementById('cart-popup');
    popup.classList.toggle('hidden');
}

document.getElementById('confirm-form').addEventListener('submit', function(e) {
    e.preventDefault();
    const data = new FormData(this);
    if (data.get("captcha") !== "8") {
        document.getElementById("form-status").innerText = "❌ Ошибка: неверная капча!";
        return;
    }
    fetch("https://api.telegram.org/bot7616111497:AAGmiCSgMO009YBUdFqg4ZLW8PbAqKV0CWI/sendMessage", {
        method: "POST",
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
            chat_id: "5157484592",
            text: `📥 Новое подтверждение оплаты:
👤 Имя: ${data.get("name")}
📱 Контакт: ${data.get("contact")}
💰 Сумма: ${data.get("amount")} ₽
📝 Комментарий: ${data.get("comment")}`
        })
    }).then(() => {
        document.getElementById("form-status").innerText = "✅ Подтверждение отправлено!";
        document.getElementById('confirm-form').reset();
    });
});
